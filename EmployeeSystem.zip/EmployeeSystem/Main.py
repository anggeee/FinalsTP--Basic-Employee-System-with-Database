import mysql.connector

from tkinter import *
from tkinter import ttk
from tkinter import messagebox

mydb = mysql.connector.connect(host="localhost", user="root", passwd="root", database="employee")


data = []


class Animal:
    def __init__(self, id, name, position):
        self.id = id
        self.name = name
        self.position = position

    def getId(self):
        return self.id

    def getName(self):
        return self.name

    def getPosition(self):
        return self.position


# Frame
root = Tk()
root.resizable(0, 0)
root.title("Basic Employee System with Database")
# root.geometry("750x500")
root.configure(background='#BDC3C7')


# Photos
photo_add = PhotoImage(file=r"C:\Users\lenovo\PycharmProjects\Pictures\add.png")
photo_delete = PhotoImage(file=r"C:\Users\lenovo\PycharmProjects\Pictures\delete.png")
photo_update = PhotoImage(file=r"C:\Users\lenovo\PycharmProjects\Pictures\update.png")
photo_exit = PhotoImage(file=r"C:\Users\lenovo\PycharmProjects\Pictures\exit.png")



def addEmployees():
    # tv.insert('', 'end', text=e1.get(), values=(e1.get(), e2.get(), e3.get()))
    # messagebox.showinfo("Information", "Added")

    id = e1.get()
    name = e2.get();
    position = e3.get();

    if (id == "" or name == "" or position == ""):
        messagebox.showinfo("Insert Status", "All fields are Required")
    else:
        con = mysql.connector.connect(host="localhost", user="root", passwd="root", database="employee")
        cursor = con.cursor()
        cursor.execute("insert into employee_info values('" + id + "', '" + name + "', '" + position + "')")
        cursor.execute("commit")

        tv.insert('', 'end', text=e1.get(), values=(e1.get(), e2.get(), e3.get()))

        e1.delete(0, 'end')
        e2.delete(0, 'end')
        e3.delete(0, 'end')

        messagebox.showinfo("Insert Status", "Added Successfully")
        con.close();



def delete_items():
    # confirm = messagebox.askquestion("Delete", "Are you sure to delete this data ?")
    # if confirm == "yes":

    # else:
    #   print(" ")

    if (e1.get() == ""):
        messagebox.showinfo("Delete Status", "ID aren't able to delete")
    else:
        con = mysql.connector.connect(host="localhost", user="root", passwd="root", database="employee")
        cursor = con.cursor()
        cursor.execute("delete from employee_info where id='" + e1.get() + "'")
        cursor.execute("commit")

        e1.delete(0, 'end')

        selected_items = tv.selection()[0]
        tv.delete(selected_items)

        messagebox.showinfo("Deletion Status", "Deleted Successfully")
        con.close();


def dataExit():
    i = messagebox.askquestion("Warning", " Are you sure to leave this page? ")
    if i == "yes":
        messagebox.showinfo("Information","Thank you")
        root.destroy()
    else:
        print(" ")



def UpdateData():
    id = e1.get()
    name = e2.get();
    position = e3.get();

    if (id == "" or name == "" or position == ""):
        messagebox.showinfo("Update Status", "All fields are Required")
    else:
        con = mysql.connector.connect(host="localhost", user="root", passwd="root", database="employee")
        cursor = con.cursor()
        cursor.execute("update employee_info set name='" + name + "', position='" + position + "' where id='" + id + "'")
        cursor.execute("commit")

        selected_items = tv.selection()[0]
        tv.item(selected_items, text=e1.get(), values=(e1.get(), e2.get(), e3.get()))

        e1.delete(0, 'end')
        e2.delete(0, 'end')
        e3.delete(0, 'end')

        messagebox.showinfo("Update Status", "Updated Successfully")
        con.close();

def updateData():
    records = tv.get_children()

    for element in records:
        tv.delete(element)

    con = mysql.connector.connect(host="localhost", user="root", passwd="root", database="employee")
    cursor = con.cursor()

    query = ("select * from employee_info")
    cursor.execute(query)
    data = cursor.fetchall()

    for row in data:
        tv.insert('', 'end', text = row[0], values=(row[0], row[1],row[2]))
    con.close();



# Label
Label(root, text="Basic Employee System", bg='#BDC3C7', font="Calibri 16 bold").grid(row=1, column=1)
Label(root, text="Employee ID", bg='#BDC3C7', font="Calibri 14 bold").grid(row=2, column=0, padx=10, pady=10)
Label(root, text="Name", bg='#BDC3C7', font="Calibri 14 bold").grid(row=3, column=0, padx=3, pady=10)
Label(root, text="Position", bg='#BDC3C7', font="Calibri 14 bold").grid(row=4, column=0, padx=3, pady=10)

# Textbox
e1 = Entry(root, width=30)
e1.grid(row=2, column=1, padx=5, pady=10)
e2 = Entry(root, width=30)
e2.grid(row=3, column=1, padx=5, pady=10)
e3 = Entry(root, width=30)
e3.grid(row=4, column=1, padx=5, pady=10)

# Button
btn_add = Button(root, text="Add", image=photo_add, width=50, height=50, command=addEmployees).grid(row=6, column=0, padx=0, pady=3 , sticky=E)
btn_remove = Button(root, text="Delete", image=photo_delete, width=50, height=50, command=delete_items).grid(row=6,column=1,padx=1,pady=3,sticky=W)
btn_update = Button(root, text="Update", image=photo_update, width=50, height=50, command=UpdateData).grid(row=6,column=2,padx=1,pady=3)
btn_exit = Button(root, text="Exit", image=photo_exit, width=50, height=50, command=dataExit).grid(row=6, column=3,padx=1, pady=5)


# Table
tv = ttk.Treeview(root, column=("Name", "Breed", "Status"), show="headings")
tv.heading('#1', text='ID')
tv.heading('#2', text='NAME')
tv.heading('#3', text='POSITION')
tv.grid(row=50, column=1, padx=10, pady=10)

updateData()

root.mainloop()
