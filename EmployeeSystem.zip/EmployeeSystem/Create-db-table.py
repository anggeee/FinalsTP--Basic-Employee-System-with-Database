import mysql.connector
mydb = mysql.connector.connect(host="localhost", user="root", passwd="root", database="employee")

mycursor = mydb.cursor()

mycursor.execute("Show tables")

for tb in mycursor:
    print(tb)